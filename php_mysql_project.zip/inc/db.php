<?php
$mydb = new mysqli("localhost","root","","decora");
?>