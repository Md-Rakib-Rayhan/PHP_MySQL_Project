# Changelog

All notable changes to this template will be documented in this file.

## [1.0.0] - [2022-02-11]

### Added

- Initial Release
